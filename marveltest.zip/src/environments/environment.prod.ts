export const environment = {
  production: true,
  api: 'https://gateway.marvel.com/v1/public',
  publicKey: 'ff7d89acc8f903790a0dec9bfe3291ca',
  privateKey: 'decd878a81fd00a472d9b4976ba4fe73fe86318f'
};
