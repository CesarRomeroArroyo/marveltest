
export type RequestParameter = {
    searchText?: string;
    orderBy?: string;
    offset?: number;
    limit?: number;
}