
export type SelectOrder = {
    text: string;
    value: string;
}