import { CharacterImagePipe } from './character-image.pipe';

describe('CharacterImagePipe', () => {
  it('create an instance', () => {
    const pipe = new CharacterImagePipe();
    expect(pipe).toBeTruthy();
  });
});
