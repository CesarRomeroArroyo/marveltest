
export const listOptions = [
  { value: 'name', text: 'Nombre' },
  { value: 'modified', text: 'Fecha de Modificación' }
]